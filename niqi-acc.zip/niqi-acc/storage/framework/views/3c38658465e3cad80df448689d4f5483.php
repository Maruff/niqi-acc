<div <?php echo e($attributes->class(['fi-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/esan/Documents/projects/niqi-acc/vendor/filament/support/src/../resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>